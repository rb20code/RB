import os
import shutil


folderpath = r'SOURCE FOLDER' #Source Folder
os.chdir(folderpath)
os.getcwd()

os.listdir()


list_extension = []
for fname in os.listdir():
    extension = fname.split(".")[-1]  #MX.mp3 {.mp3}
    list_extension.append(extension)
    # print(list_extension)

list_extension = set(list_extension)
print(list_extension)
print(len(list_extension))



path = os.environ["UserProfile"] + "\\" + "Desktop" + "\\" + 'FOLDER NAME THAT YOU WANT TO CREATE'
print(path)
os.mkdir(path)
try:
    shutil.rmtree(path)
    os.mkdir(path)
except:
    os.mkdir(path)


for ex in list_extension:
    print(ex, end=",")
    os.mkdir(path + "\\" + ex)
    for fname in os.listdir():
        if ex in fname:
            shutil.copy(fname, path + "\\" + ex)